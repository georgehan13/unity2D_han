﻿using UnityEngine;
using System.Collections;

public class DestroyZone : MonoBehaviour 
{
	void OnCollisionEnter2D(Collision2D other)
	{
		Destroy (other.gameObject);
	}

}
